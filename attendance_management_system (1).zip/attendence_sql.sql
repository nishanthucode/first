-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2024 at 07:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendence`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `record_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `date` date DEFAULT curdate(),
  `attendance_status` enum('Present','Absent') DEFAULT 'Absent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`record_id`, `student_id`, `subject_id`, `date`, `attendance_status`) VALUES
(1, 25, 3, '2024-02-12', 'Present'),
(2, 25, 3, '2024-02-13', 'Absent'),
(3, 25, 3, '2024-02-19', 'Present'),
(4, 25, 3, '2024-02-26', 'Present'),
(5, 25, 3, '2024-03-04', 'Present'),
(6, 25, 3, '2024-03-25', 'Present'),
(7, 25, 3, '2024-02-06', 'Present'),
(8, 25, 3, '2024-02-20', 'Present'),
(9, 25, 3, '2024-02-27', 'Present'),
(10, 25, 3, '2024-03-05', 'Present'),
(11, 25, 3, '2024-03-26', 'Present'),
(12, 25, 3, '2024-02-07', 'Present'),
(13, 25, 3, '2024-02-28', 'Present'),
(14, 25, 3, '2024-03-06', 'Present'),
(15, 25, 3, '2024-03-27', 'Present'),
(16, 25, 3, '2024-02-23', 'Present'),
(17, 25, 7, '2024-05-03', 'Present'),
(18, 25, 2, '2024-05-03', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `days`
--

CREATE TABLE `days` (
  `id` int(11) NOT NULL,
  `day_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `days`
--

INSERT INTO `days` (`id`, `day_name`) VALUES
(1, 'Monday'),
(2, 'Tuesday'),
(3, 'Wednesday'),
(4, 'Thursday'),
(5, 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `subjects` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `email`, `password`, `subjects`) VALUES
(1, 'Gururaj S', 'gururaj@gmail.com', 'gururaj', 'CFOS'),
(2, 'Sunith Kumar T', 'sunith@gmail.com', 'sunith', 'DSA'),
(3, 'Jayashree', 'jayashree@gmail.com', 'jayashree', 'RM&IPR'),
(4, 'Amita Roshan Vakil', 'amita@gmail.com', 'amita', 'DBMS'),
(5, 'Priyadarshini P', 'priyadarshini@gmail.com', 'priyadarshini', 'WEB'),
(6, 'Aleyamma George', 'aleyamma@gmail.com', 'aleyamma', 'DMS'),
(7, 'Harsha A J', 'harsha@gmail.com', 'harsha', 'IOT'),
(8, 'Sumangala N', 'sumangala@gmail.com', 'sumangala', 'FP-BC'),
(9, 'Sunith Kumar T (B1)', 'sunithb1@gmail.com', 'sunith', 'DSA-B1/DBMS-B2'),
(10, 'Amita Roshan Vakil(B1)', 'amitab1@gmail.com', 'amita', 'DBMS-B1/WEB-B2'),
(11, 'Priyadarshini P (B1)', 'priyadarshinib1@gmail.com', 'priyadarshini', 'WEB-B1/DSA-B2'),
(12, 'Sunith Kumar T (B2)', 'sunithb2@gmail.com', 'sunith', 'WEB-B1/DSA-B2'),
(13, 'Amita Roshan Vakil(B2)', 'amitab2@gmail.com', 'amita', 'DSA-B1/DBMS-B2'),
(14, 'Priyadarshini P (B2)', 'priyadarshinib2@gmail.com', 'priyadarshini', 'DBMS-B1/WEB-B2'),
(15, 'Sathyendra Bhat', 'sathyendra@gmail.com', 'sathyendra', 'Idea Lab');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_name`, `email`, `password`) VALUES
(1, 'Nisha H', 'nisha@gmail.com', 'nisha'),
(2, 'Nishanth U', 'nishanthu@gmail.com', 'nishanthu'),
(3, 'Nithesh', 'nithesh@gmail.com', 'nithesh'),
(4, 'Numan Mohammed Rafiq Mirjankar', 'numanmohammed@gmail.com', 'numanmohammed'),
(5, 'Pallavi', 'pallavi@gmail.com', 'pallavi'),
(6, 'Pavan Kumar Nayak S', 'pavankumar@gmail.com', 'pavankumar'),
(7, 'Pavith Raj', 'pavith@gmail.com', 'pavith'),
(8, 'Pawan Kumar K P', 'pawankumar@gmail.com', 'pawankumar'),
(9, 'Pooja S P', 'poojasp@gmail.com', 'poojasp'),
(10, 'Pragathi Jayakar', 'pragathi@gmail.com', 'pragathi'),
(11, 'Praneeth Kumar Gowda', 'praneethkumar@gmail.com', 'praneethkumar'),
(12, 'Pratheek Kishore Kottari', 'pratheekkishore@gmail.com', 'pratheekkishore'),
(13, 'Prathiksha K', 'prathiksha@gmail.com', 'prathiksha'),
(14, 'Priya H', 'priya@gmail.com', 'priya'),
(15, 'Rahul A', 'rahul@gmail.com', 'rahul'),
(16, 'Rakshith Kumar', 'rakshithkumar@gmail.com', 'rakshithkumar'),
(17, 'Rakshith R Suvarna', 'rakshithsuvarna@gmail.com', 'rakshithsuvarna'),
(18, 'Rakshith Rai A', 'rakshithrai@gmail.com', 'rakshithrai'),
(19, 'Rashmi R Kotian', 'rashmikotian@gmail.com', 'rashmikotian'),
(20, 'Rashmita S Shet', 'rashmitashet@gmail.com', 'rashmitashet'),
(21, 'Rithesh Sudhakar', 'ritheshsudhakar@gmail.com', 'ritheshsudhakar'),
(22, 'Royston Mendonca', 'royston@gmail.com', 'royston'),
(23, 'Saksha Shetty', 'saksha@gmail.com', 'saksha'),
(24, 'Sanjana SK', 'sanjana@gmail.com', 'sanjana'),
(25, 'Sanketh', 'sanketh@gmail.com', 'sanketh'),
(26, 'Sharath Kumar B', 'sharathkumar@gmail.com', 'sharathkumar'),
(27, 'Sharath Naik', 'sharathnaik@gmail.com', 'sharathnaik'),
(28, 'Sharwari Krishna C', 'sharwari@gmail.com', 'sharwari'),
(29, 'Sheral Mascarenhas', 'sheral@gmail.com', 'sheral'),
(30, 'Sherwin Ashton Dsouza', 'sherwin@gmail.com', 'sherwin'),
(31, 'Shetty Nimesh Vasu R', 'shettynimesh@gmail.com', 'shettynimesh'),
(32, 'Shraddha', 'shraddha@gmail.com', 'shraddha'),
(33, 'Shraddha PV', 'shraddhapv@gmail.com', 'shraddhapv'),
(34, 'Shravan K', 'shravan@gmail.com', 'shravan'),
(35, 'Shravya P', 'shravya@gmail.com', 'shravya'),
(36, 'Shravyashree', 'shravyashree@gmail.com', 'shravyashree'),
(37, 'Shreya K', 'shreyak@gmail.com', 'shreyak'),
(38, 'Shreya K Shet', 'shreyashet@gmail.com', 'shreyashet'),
(39, 'Shreya MD', 'shreyamd@gmail.com', 'shreyamd'),
(40, 'Shridevi RN', 'shridevi@gmail.com', 'shridevi'),
(41, 'Sonal Riva Gonsalves', 'sonalriva@gmail.com', 'sonalriva'),
(42, 'Sonika', 'sonika@gmail.com', 'sonika'),
(43, 'Soujanya', 'soujanya@gmail.com', 'soujanya'),
(44, 'Sreeraj A', 'sreeraj@gmail.com', 'sreeraj'),
(45, 'Stan Avil Dsouza', 'standsouza@gmail.com', 'stand'),
(46, 'Sumana', 'sumana@gmail.com', 'sumana'),
(47, 'Sushmitha Monthero', 'sushmitha@gmail.com', 'sushmitha'),
(48, 'Swasthi Umesh Bhandary', 'swasthi@gmail.com', 'swasthi'),
(49, 'Thashwin S', 'thashwin@gmail.com', 'thashwin'),
(50, 'Thejaswini', 'thejaswini@gmail.com', 'thejaswini'),
(51, 'Thulasi', 'thulasi@gmail.com', 'thulasi'),
(52, 'Thushara', 'thushara@gmail.com', 'thushara'),
(53, 'Vaishali', 'vaishali@gmail.com', 'vaishali'),
(54, 'Varshitha Rai', 'varshitha@gmail.com', 'varshitha'),
(55, 'Veeksha A', 'veeksha@gmail.com', 'veeksha'),
(56, 'Vidya', 'vidya@gmail.com', 'vidya'),
(57, 'Vikyath Kumar', 'vikyathkumar@gmail.com', 'vikyathkumar'),
(58, 'Vishakha Divakar Puthran', 'vishakha@gmail.com', 'vishakha'),
(59, 'Vivian Dsouza', 'vivian@gmail.com', 'vivian'),
(60, 'Yashwin V Shettigar', 'yashwin@gmail.com', 'yashwin');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`) VALUES
(1, 'DBMS'),
(2, 'DMS'),
(3, 'CFOS'),
(4, 'RM&IPR'),
(5, 'DBMS-B1/WEB-B2'),
(6, 'DSA'),
(7, 'WEB'),
(8, 'IOT'),
(9, 'FP-BC'),
(10, 'DSA-B1/DBMS-B2'),
(11, 'Idea Lab'),
(12, 'WEB-B1/DSA-B2');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `day_id` int(11) DEFAULT NULL,
  `time_slot_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `day_id`, `time_slot_id`, `subject_id`) VALUES
(1, 1, 1, 1),
(2, 1, 2, 2),
(3, 1, 3, 3),
(4, 1, 4, 4),
(5, 1, 5, 5),
(6, 1, 6, 5),
(7, 1, 7, 5),
(8, 2, 1, 3),
(9, 2, 2, 2),
(10, 2, 3, 6),
(11, 2, 4, 7),
(12, 2, 5, 12),
(13, 2, 6, 12),
(14, 2, 7, 12),
(15, 3, 1, 6),
(16, 3, 2, 2),
(17, 3, 3, 1),
(18, 3, 4, 3),
(19, 3, 5, 8),
(20, 3, 6, 9),
(21, 3, 7, 9),
(22, 4, 1, 6),
(23, 4, 2, 8),
(24, 4, 3, 7),
(25, 4, 4, 1),
(26, 4, 5, 4),
(27, 4, 6, 11),
(28, 4, 7, 11),
(29, 5, 1, 7),
(30, 5, 2, 2),
(31, 5, 3, 3),
(32, 5, 4, 6),
(33, 5, 5, 10),
(34, 5, 6, 10),
(35, 5, 7, 10);

-- --------------------------------------------------------

--
-- Table structure for table `time_slots`
--

CREATE TABLE `time_slots` (
  `id` int(11) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `time_slots`
--

INSERT INTO `time_slots` (`id`, `start_time`, `end_time`) VALUES
(1, '09:00:00', '09:55:00'),
(2, '09:55:00', '10:50:00'),
(3, '11:10:00', '12:05:00'),
(4, '12:05:00', '01:00:00'),
(5, '02:00:00', '03:00:00'),
(6, '03:00:00', '04:00:00'),
(7, '04:00:00', '05:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `days`
--
ALTER TABLE `days`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `day_id` (`day_id`),
  ADD KEY `time_slot_id` (`time_slot_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `time_slots`
--
ALTER TABLE `time_slots`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `days`
--
ALTER TABLE `days`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `time_slots`
--
ALTER TABLE `time_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD CONSTRAINT `attendance_records_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  ADD CONSTRAINT `attendance_records_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
  ADD CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`day_id`) REFERENCES `days` (`id`),
  ADD CONSTRAINT `timetable_ibfk_2` FOREIGN KEY (`time_slot_id`) REFERENCES `time_slots` (`id`),
  ADD CONSTRAINT `timetable_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
